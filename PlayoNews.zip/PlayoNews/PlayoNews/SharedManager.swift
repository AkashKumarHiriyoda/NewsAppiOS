//
//  NewListTableViewCell.swift
//  PlayoNews

import UIKit
import MBProgressHUD

class SharedManager: NSObject {
    
   class func showHUD(viewController: UIViewController)
    {
        let hud = MBProgressHUD.showAdded(to: viewController.view, animated: true)
        hud.label.text = NSLocalizedString("Loading", comment: "")
        hud.contentColor = .black
    }
    
   class func dismissHUD(viewController: UIViewController)
    {
        MBProgressHUD.hide(for: viewController.view, animated: true)
    }
    
    class func checkForInternetConnection() -> Bool
    {
        return true
    }
    
    class func showErrorConnectionViewController()
    {
    }
    
    
    class func showAlertWithMessage(title: String, alertMessage: String, viewController: UIViewController)
    {
        let alert = UIAlertController(title: title, message: alertMessage, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: ""), style: .default, handler: nil))
        viewController.present(alert, animated: true, completion: nil)
        
    }
}
