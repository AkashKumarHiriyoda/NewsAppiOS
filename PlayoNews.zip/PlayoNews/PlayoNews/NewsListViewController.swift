//
//  ViewController.swift
//  PlayoNews

import UIKit
import Alamofire
import SDWebImage

struct News {
    var newsTitle:String!
    var newsDescription:String!
    var newsAuthor:String!
    var newsImage:String!
    var newsWebUrl:String!
    
    init(newsDetails:[String:AnyObject]) {
        self.newsTitle = "\(newsDetails["title"] ?? "" as AnyObject)"
        self.newsDescription = "\(newsDetails["description"] ?? "" as AnyObject)"
        self.newsAuthor = "\(newsDetails["author"] ?? "" as AnyObject)"
        self.newsImage = "\(newsDetails["urlToImage"] ?? "" as AnyObject)"
        self.newsWebUrl = "\(newsDetails["url"] ?? "" as AnyObject)"
    }
}

class NewsListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tblNewsList: UITableView!
    
    var newsList:[News] = []
    var cellHeight : CGFloat = 0
    var apiKey = "a88440290a8543febb7d56201f81c8d2"
    var refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Playo News"
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(pullToRefresh), for: .valueChanged)
        tblNewsList.addSubview(refreshControl)
        
        getNewsList()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if newsList.count != 0 {
            return newsList.count
        }else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if newsList.count != 0 {
            let cell:NewsListTableViewCell = self.tblNewsList.dequeueReusableCell(withIdentifier: "newsListCell") as! NewsListTableViewCell
            
            cell.lblTitle.text = newsList[indexPath.row].newsTitle
            cell.lblTitle.sizeToFit()
            
            cell.lblDescription.frame.origin.y = cell.lblTitle.frame.origin.y + cell.lblTitle.frame.size.height + 5
            cell.lblDescription.text = newsList[indexPath.row].newsDescription
            cell.lblDescription.sizeToFit()
            
            cell.lblAuthor.frame.origin.y = cell.lblDescription.frame.origin.y + cell.lblDescription.frame.size.height + 5
            cell.lblAuthor.text = newsList[indexPath.row].newsAuthor
            
            cell.viewContainer.frame.size.height = cell.lblAuthor.frame.origin.y + cell.lblAuthor.frame.size.height + 5
            cell.viewContainer.frame.size.width = self.view.frame.size.width
            cellHeight = cell.viewContainer.frame.origin.y + cell.viewContainer.frame.size.height + 5
            
            cell.lblTitle.translatesAutoresizingMaskIntoConstraints = true
            cell.lblDescription.translatesAutoresizingMaskIntoConstraints = true
            cell.lblAuthor.translatesAutoresizingMaskIntoConstraints = true
            cell.viewContainer.translatesAutoresizingMaskIntoConstraints = true
            
            let imageUrl = newsList[indexPath.row].newsImage
            let trimmedUrl = imageUrl?.trimmingCharacters(in: CharacterSet(charactersIn: "")).replacingOccurrences(of: " ", with: "%20")
            
            var activityLoader = UIActivityIndicatorView()
            activityLoader = UIActivityIndicatorView(style: .gray)
            activityLoader.center = cell.imgNews.center
            activityLoader.startAnimating()
            cell.imgNews.addSubview(activityLoader)
            
            cell.imgNews.sd_setImage(with: URL(string: trimmedUrl!), completed: { (image, error, imageCacheType, imageUrl) in
                
                if image != nil
                {
                    activityLoader.stopAnimating()
                }
                else
                {
                    print("image not found")
                    activityLoader.stopAnimating()
                }
            })
            
            return cell
        }else {
            let cell:NewsListTableViewCell = self.tblNewsList.dequeueReusableCell(withIdentifier: "noNewsListCell") as! NewsListTableViewCell
            
            cell.lblNoNews.text = NSLocalizedString("Data Not Found !", comment: "")
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if #available(iOS 15.0, *) {
            tableView.sectionHeaderTopPadding = 0
        }
        
        if newsList.count != 0 {
            return cellHeight
        }else {
            return 50
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if newsList.count != 0 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "NewsWebViewController") as! NewsWebViewController
            vc.urlToLoad = newsList[indexPath.row].newsWebUrl
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func pullToRefresh(refreshControl: UIRefreshControl) {
        getNewsList()
    }
    
    func getNewsList() {
        SharedManager.showHUD(viewController: self)
        let urlStr = "https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=\(apiKey)"
        let setFinalURl = urlStr.addingPercentEncoding (withAllowedCharacters: .urlQueryAllowed)!
        var request = URLRequest(url: URL(string: setFinalURl)!, cachePolicy: URLRequest.CachePolicy.reloadIgnoringCacheData, timeoutInterval: 60)
        request.httpMethod = HTTPMethod.get.rawValue
        
        if Connectivity.isConnectedToInternet() {
            Alamofire.request(request).responseJSON { (responseObject) -> Void in
                
                if responseObject.result.isSuccess {
                    SharedManager.dismissHUD(viewController: self)
                    let result = responseObject.result.value! as AnyObject
                    
                    if let code = result.value(forKey: "status") {
                        self.tblNewsList.isHidden = false
                        if code as! String == "ok" {
                            let dict = result as! NSDictionary
                            let list = dict.value(forKey: "articles") as! [[String:AnyObject]]
                            self.newsList = list.map({ News(newsDetails: $0) })
                            
                            self.tblNewsList.reloadData()
                        }else {
                            SharedManager.showAlertWithMessage(title: NSLocalizedString("Sorry", comment: ""), alertMessage: result.value(forKey: "message") as! String, viewController: self)
                        }
                        
                        //Refresh Control
                        if self.refreshControl.isRefreshing {
                            self.refreshControl.endRefreshing()
                        }else {
                            print("refreshControl not began")
                        }
                    }else {
                        SharedManager.showAlertWithMessage(title: NSLocalizedString("Sorry", comment: ""), alertMessage: "Something went wrong", viewController: self)
                    }
                }
                if responseObject.result.isFailure {
                    SharedManager.dismissHUD(viewController: self)
                    let error : Error = responseObject.result.error!
                    print(error.localizedDescription)
                    SharedManager.showAlertWithMessage(title: NSLocalizedString("Sorry", comment: ""), alertMessage: "Something went wrong", viewController: self)
                }
            }
        }else {
            SharedManager.showAlertWithMessage(title: NSLocalizedString("Sorry", comment: ""), alertMessage: NSLocalizedString("The Internet connection appears to be offline", comment: ""), viewController: self)
        }
    }
}

class Connectivity {
    class func isConnectedToInternet() ->Bool {
        return NetworkReachabilityManager()!.isReachable
    }
}

