//
//  NewsWebViewController.swift
//  PlayoNews


import UIKit
import WebKit

class NewsWebViewController: UIViewController, WKNavigationDelegate {

    @IBOutlet weak var newsWebView: WKWebView!
    var urlToLoad : String = ""
    
    override func loadView() {
        super.loadView()
        newsWebView.navigationDelegate = self
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        SharedManager.showHUD(viewController: self)
        let url = URL(string: urlToLoad)!
        newsWebView.load(URLRequest(url: url))
        newsWebView.allowsBackForwardNavigationGestures = true
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!)
    {
        SharedManager.dismissHUD(viewController: self)
    }
}
